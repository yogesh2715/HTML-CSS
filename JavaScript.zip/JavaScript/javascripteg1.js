
// var a=confirm("Please check Contact Number");
// document.write(a+"<br>")



// var b=alert("please check Email address....")
// document.write(b+"<br>")

// var c=prompt("Enter Your Name...")
// document.write(c)


var a=10.5;
document.write(a+"<br>");
document.write(typeof(a+"<br>"));


var b="hello class"
console.log(typeof(b+"<br>"))


var x=true;
var x=false;
console.log(typeof(x));
console.log(typeof(y));


var x1;
console.log(typeof(x1));

var a1=null;
console.log(typeof(a1))

